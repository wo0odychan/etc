const pages = gsap.utils.toArray('#hscroll .page');
console.log(pages);

gsap.to(pages, {
    xPercent: -100 * (pages.length - 1),
    duration: 3,
    scrollTrigger: {
        trigger: '#hscroll',
        start: 'top top',
        // end: 'bottom bottom',
        scrub: true,
        pin: true,
        // snap: { //공간 단위로 스냅 붙이기 근데 스냅이 머임?
        //     snapTo: 1 / (pages.length - 1),
        //     inertia: true,
        //     duration: { min: 1, max: 1 },

        // }
    }
})