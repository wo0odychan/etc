$(function () {
    $('.main_pic ul').slick({
        arrows: false,
        slidesToShow: 2,

    });

})