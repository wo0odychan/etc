<ul class="submenu">
    <li><a href="<?=G5_THEME_URL?>/doc/m021.php">제품01</a></li>
    <li><a href="">서버메뉴02</a></li>
    <li><a href="">서버메뉴03</a></li>
</ul>