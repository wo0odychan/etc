<? 
$cate_title = '회사소개';
$page_title = '연혁';
$cate_num = 1;
$page_num = 2;
include '../../../common.php';
include_once(G5_THEME_PATH.'/head.php');
?>



<div class="content">
<h3><?=$page_title;?></h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus maxime dolorum cupiditate
                    architecto quaerat id natus alias. Magnam, possimus nam?
                </p>
</div>


<? 
include_once(G5_THEME_PATH.'/tail.php');
?>
