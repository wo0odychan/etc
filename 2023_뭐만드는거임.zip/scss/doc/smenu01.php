<ul class="submenu">
    <li><a href="<?=G5_THEME_URL?>/doc/m011.php">인사말</a></li>
    <li><a href="<?=G5_THEME_URL?>/doc/m012.php">연혁</a></li>
    <li><a href="<?=G5_THEME_URL?>/doc/m013.php">오시는길</a></li>
</ul>